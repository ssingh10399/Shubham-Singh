#include<stdio.h>
#include<iostream>
#include<math.h>
using namespace std;
class Node;
void append(Node**, int);
void printList(Node*);
void sepDigit(Node**, int);
int getLength(Node*);
int convDigit(Node*);
void reverse(Node*);

int main()
{
    Node* head = NULL;
    Node* new_head = NULL;
    sepDigit(&head, 123);
    sepDigit(&new_head, 456);
    int a = convDigit(head);
    int b = convDigit(new_head);
    int sum;
    sum = a+b;
    cout<<"The Sum is "<<sum;
    Node* sum_head = NULL;
    sepDigit(&sum_head, sum);
    cout<<"\n";
    printList(sum_head);
    return 0;
}

class Node{
    public:
        int data;
        Node* next;
};

void append(Node** head_ref, int data_ref){
    Node* new_node = new Node();
    new_node->next = NULL;
    new_node->data = data_ref;

    if (*head_ref == NULL){
        (*head_ref) = new_node;
        return;
    }

    Node* current = (*head_ref);
    while(current->next!=NULL)
        current = current->next;

    current->next = new_node;
    return;

}

void printList(Node* head_ref){
    Node* current = head_ref;
    while (current!=NULL){
        cout<<current->data<<" ";
        current = current->next;
    }
}

void sepDigit(Node** head_ref, int n){
    int temp = n, d = 0;
    
    while (temp>=1){
        d = temp % 10;
        temp = temp / 10;
        append(head_ref, d);
 
    }
 
    
}

int getLength(Node* head_ref){
        Node* current = head_ref;
        int count = 0;
        if (head_ref == NULL){
            return 0;
        }
        while (current!=NULL){
            count++;
            current = current->next;
        }
        return count;
}

int convDigit(Node* head_ref){
    Node* current = head_ref;
    int l = getLength(head_ref)-1, sum = 0, d = 0;
    while(current!=NULL){
        d = (current->data) * (pow(10,l));
        l--;
        sum = sum + d;
        current = current->next;
    }
    return sum;

}

 void reverse(Node* head_ref) 
    { 
        Node* current = head_ref; 
        Node *prev = NULL, *next = NULL; 
  
        while (current != NULL) { 
            next = current->next; 
  
            current->next = prev; 
  
            prev = current; 
            current = next; 
        } 
        head_ref = prev; 
    } 
