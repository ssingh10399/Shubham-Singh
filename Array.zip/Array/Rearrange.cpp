#include<bits/stdc++.h> 
using namespace std;  
int fix(int A[], int len) 
{ 
	for(int i = 0; i < len; i++) 
	{ 
		if (A[i] != - 1 && A[i] != i) 
		{ 
			int x = A[i]; 
			while (A[x] != -1 && A[x] != x) 
			{ 
				int y = A[x];  
				A[x] = x; 
				x = y; 
			}  
			A[x] = x; 
			if (A[i] != i) 
			{ 
				A[i] = -1; 
			} 
		} 
	} 
}  
int main() 
{ 
	int A[] = { -1, -1, 6, 1, 9, 3, 2, -1, 4, -1 }; 
	int len = sizeof(A) / sizeof(A[0]); 
	fix(A, len); 
	for (int i = 0; i < len; i++) 
	cout << A[i] << " "; 
} 

