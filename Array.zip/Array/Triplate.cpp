#include <bits/stdc++.h> 
using namespace std; 
int maxTripletSum(int arr[], int n) 
{
	sort(arr, arr + n); 
	return arr[n - 1] + arr[n - 2] + arr[n - 3]; 
} 
int main() 
{ 
	int arr[] = { 1, 0, 8, 6, 4, 2 }; 
	int n = sizeof(arr) / sizeof(arr[0]); 
	cout << maxTripletSum(arr, n); 
	return 0; 
} 

